<?php

namespace WPForms\Vendor\Stripe\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
