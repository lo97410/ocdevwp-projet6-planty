<?php

// File generated from our OpenAPI spec
namespace WPForms\Vendor\Stripe\Util;

class ApiVersion
{
    const CURRENT = '2024-06-20';
}
